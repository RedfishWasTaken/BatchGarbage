Hello! I'm not responsible for any damage to your computer.
I recommend you to run this on virtual machine (VMware, VirtualBox)
Have fun!